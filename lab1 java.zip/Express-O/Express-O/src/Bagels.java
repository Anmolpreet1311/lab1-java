/**
 * Bagel
 * @version 1.0
 * @since yesterday
 * @author tarn
 * */
public class Bagels extends Product{
    private boolean toasted;
    private boolean creamCheese;
    private boolean butter;

    /**
     *
     * @param name Name of the bagel
     * @param toasted Do You want it toasted or not
     * @param creamCheese Do You want cream cheese on it or not
     * @param butter Do You want butter on it or not
     */

    public Bagels(String name, boolean toasted, boolean creamCheese, boolean butter) {
        super(name,2.50);
        this.toasted = toasted;
        this.creamCheese = creamCheese;
        this.butter = butter;
    }

    public boolean isToasted() {
        return toasted;
    }

    public void setToasted(boolean toasted) {
        this.toasted = toasted;
    }

    public boolean isCreamCheese() {
        return creamCheese;
    }

    public void setCreamCheese(boolean creamCheese) {
        this.creamCheese = creamCheese;
    }

    public boolean isButter() {
        return butter;
    }

    public void setButter(boolean butter) {
        this.butter = butter;
    }

    /**
     *
     * @param x Amount you have to Spend
     * @return
     */
    public static int howManyBagels(double x){
        int y;
        y= (int) (x%Cost);

        return y;
    }
}
